import "./ContactFormStyles.css";

function ContactForm() {
  return (
    <div className="from-container">
      <h1>Your Code Here</h1>
    </div>
  );
}

export default ContactForm;
