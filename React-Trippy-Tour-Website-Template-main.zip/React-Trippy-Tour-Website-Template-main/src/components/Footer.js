import "./FooterStyles.css";

const Footer = () => {
  return (
    <div className="footer">
      <h1>Your Code Here</h1>
    </div>
  );
};

export default Footer;
