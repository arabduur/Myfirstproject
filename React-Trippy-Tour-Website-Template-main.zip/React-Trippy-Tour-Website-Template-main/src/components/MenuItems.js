export const MenuItems = [
  // Make a list of Navlinks & their properties.
];
