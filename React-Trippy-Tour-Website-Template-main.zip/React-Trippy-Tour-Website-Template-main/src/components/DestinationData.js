import { Component } from "react";
import "./DestinationStyles.css";

class DestinationData extends Component {
  render() {
    return (
      <div>
        <h1>Your Code Here</h1>
      </div>
    );
  }
}

export default DestinationData;
