import "./TripStyles.css";

function TripData(props) {
  return (
    <div className="t-card">
      <h1>Your Code Here</h1>
    </div>
  );
}

export default TripData;
