import "./HeroStyles.css";

function Hero(props) {
  return (
    <>
      <div>
        <h1>Your Code Here</h1>
      </div>
    </>
  );
}

export default Hero;
